<section id="main" class="wrap">
	<section id="contents" class="Search">
		<div class="container">
			<form role="search" method="get" id="searchform" action="/" >
				<label class="screen-reader-text" for="s">Search for:</label>
				<input type="text" value="" name="s" class="s" />
				<input type="submit" class="searchsubmit" value="検索" />
			</form>
		</div>
	</section>
</section>