<nav>
	<ul>
		<!-- <li><a href="news/index.html">お知らせ</a></li>
		<li><a href="about/index.html">コーヒー部について</a></li>
		<li><a href="member/index.html">メンバーリスト</a></li>
		<li><a href="manual/index.html">マニュアル</a></li> -->
		<?php dynamic_sidebar( 'side-widget' ); ?>
	</ul>
</nav>